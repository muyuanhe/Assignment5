import math as m
import numpy as np
import matplotlib as plt
###Problem1
#F(x) = e**x - x**4

tolerance = 1e-6

def F(x):
    y = m.e**x - x**4
    return y

def bisection(a, b): # a<b, a and b are the range for x we'll look for root
    if F(a) * F(b) > 0:
        raise Exception("bisection range error")
    #while abs(a-b) > tolerance:
    c = a
    while abs(F(c)) > tolerance:
        c = (b+a)/2.0
        if abs(F(c)) <= tolerance:
            print(F(c))
            break
        elif F(a) * F(c) < 0:
            b = c
        else:
            a = c
        #print(c)
    return c

print("1st root:", bisection(-2, 0))
print("2nd root:",bisection(0, 5))
print("3rd root:",bisection(5, 10))
#print(bisection(10, 15))