import math as m
import numpy as np
import matplotlib as plt
import scipy.linalg as LA
import csv
import sys
from sympy import symbols, diff # use these two lib to make partial derivatives


# Problem 3
#opening the csv files
rows1 = []
rows2 = []
rows3 = []
with open('data_1.csv','r') as data1:
    d1 = csv.reader(data1)
    for i in d1:
        rows1.append([float(i[0]), float(i[1])])
rows1 = rows1[:95] # because the first t is 0 which leads to singular matrix
with open('data_2.csv','r') as data2:
    d2 = csv.reader(data2)
    for j in d2:
        rows2.append([float(j[0]), float(j[1])])
with open('data_3.csv','r') as data3:
    d3 = csv.reader(data3)
    for k in d3:
        rows3.append([float(k[0]), float(k[1])])
# part a
# x, y, z = symbols('x y z', real = True) This isn't working for exponetials
# f = 4*x*y + x*sin(z) + x**3 + z**8*async
# diff(f, x)
#x(t) = A*e(-t/tau)
# f = dx/dA = e^(-t/tau)
# g = dx/dtau = A*exp(-t/tau)*t/tau^2
def f1(list, A, tau): #list has t and x
    return m.exp(-list[0]/tau)-list[1] # minimum A, derivative over A
def g1(list, A, tau):
    return A*m.exp(-list[0]/tau)*list[0]/tau**2-list[1]# minimum tau
def F1(list1, list2): #list1 is list of t, x values; list2 is list of A, tau values
    return np.array([f1(list1, list2[0], list2[1]), g1(list1, list2[0], list2[1])])
def J1(list1, A, tau):
    arr =  np.array([[0 , m.exp(-list1[0]/tau)*list1[0]/tau**2], [m.exp(-list1[0]/tau)*list1[0]/tau**2 , A*m.exp(-list1[0]/tau)*list1[0]**2/tau**4 - 2*A*m.exp(-list1[0]/tau)*list1[0]/tau**3]])
    return arr
def Newton(x_init, i): # x_init is in the form [1, 2], i is iteration number
    jacobian = J1(rows1[i], x_init[0], x_init[1]) # input: list, A, tau

    #print(LA.inv(jacobian))
    funct = F1(x_init, rows1[i])
    if LA.norm(jacobian) == 0:
        x_next = x_init
    else:
        x_next = x_init - np.dot(LA.inv(jacobian), funct) #when t = 0 ,jacobian is singular
    return x_next #


#print("list val", rows1[0])


list2_init1 = [1, 2] # A, tau
list2_init2 = [2, 3]

#print(Newton(list2_init1))
kai_list = []
n = 0
#for i in range(len(rows1)):
#(rows1[i][1] - Newton(list2_init1, i)[1])**2) #return all x values

def loop_newton(x_init, i): #input i as 0
    x_old = x_init
    x_new = Newton(x_old, i)
    #kai_list.append(x_new[1])
    return x_new[1]

#loop_newton(list2_init1, i)
for i in range(len(rows1)):
    kai_list.append(loop_newton(list2_init1, i))
kai_square = 0
for j in range(len(kai_list)):
    kai_square += (rows1[j][1] - kai_list[j])**2
print(kai_square)
#kai_square = sum(kai_list)
#print(kai_square) # some calculation went wrong

### part b
### basically the same idea, with four variables this time.

def f2(list, A, tau1, B, tau2): #list has t and x
    return m.exp(-list[0]/tau1)-list[1] # minimum A
def g2(list, A, tau1, B, tau2):
    return A*m.exp(-list[0]/tau1)*list[0]/tau1**2-list[1]# minimum tau1
def h2(list, A, tau1, B, tau2):
    return m.exp(-list[0]/tau2)-list[1] # minimum B
def i2(list, A, tau1, B, tau2):
    return B*m.exp(-list[0]/tau2)*list[0]/tau2**2-list[1]# minimum tau2

def F2(list1, list2): #list1 is list of t, x values; list2 is list of A, tau1, B, tau2 values
    return np.array([f2(list1, list2[0], list2[1], list2[2], list2[3]), g2(list1, list2[0], list2[1], list2[2], list2[3]), h2(list1, list2[0], list2[1], list2[2], list2[3]),i2(list1, list2[0], list2[1], list2[2], list2[3]) ])
def J2(list1, A, tau1, B, tau2):
    arr =  np.array([[0 , m.exp(-list1[0]/tau1)*list1[0]/tau1**2, 0,  m.exp(-list1[0]/tau2)*list1[0]/tau2**2], [m.exp(-list1[0]/tau1)*list1[0]/tau1**2 , A*m.exp(-list1[0]/tau1)*list1[0]**2/tau1**4 - 2*A*m.exp(-list1[0]/tau1)*list1[0]/tau1**3, m.exp(-list1[0]/tau2)*list1[0]/tau2**2, A*m.exp(-list1[0]/tau1)*list1[0]**2/tau1**4 - 2*B*m.exp(-list1[0]/tau2)*list1[0]/tau2**3]])
    return arr
def Newton(x_init, i): # x_init is in the form [1, 2], i is iteration number
    jacobian = J1(rows1[i], x_init[0], x_init[1], x_init[2], x_init[3]) # input: list, A, tau1, B, tau2
    funct = F1(x_init, rows1[i])
    if LA.norm(jacobian) == 0:
        x_next = x_init
    else:
        x_next = x_init - np.dot(LA.inv(jacobian), funct)  # when t = 0 ,jacobian is singular
    return x_next  #
