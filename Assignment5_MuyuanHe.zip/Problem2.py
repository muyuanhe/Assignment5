import math as m
import numpy as np
import matplotlib as plt
import scipy.linalg as LA

# Problem 2
#F(x, y) = x**2*m.e**(-x**2) + y**2
#G(x, y) = x**4/(1+x**2y**2)
#F(a, b) = G(a, b) = 1
def f(x, y):
    return (x**2)*m.exp(-x**2) + y**2 -1
def g(x, y):
    return x**4/(1+(x**2)*(y**2)) -1
def F(x, y):
    return np.array([f(x, y), g(x, y)])
def J(x, y): # Jacobian
    return np.array([[2*np.exp(-x**2)*x-2*np.exp(-x**2)*x**3, 2*y], [(4*x**3)/(1+(x**2)*(y**2)) - 2*(x**5)*(y**2)/(1+2*(x**2)*(y**2)+(x**4)*y**4), float((-2)*(x**6)*y/(1+2*(x**2)*(y**2)+(x**4)*y**4))]])
def Newton(x_init): # x_init is in the form [1, 2]
    jacobian = J(x_init[0], x_init[1])
    funct = F(x_init[0], x_init[1])
    x_next = x_init - np.dot(LA.inv(jacobian), funct)
    return x_next

def loop_newton(x_init): # main function
    x_old = x_init
    x_new = Newton(x_old)
    err = x
    if err > 0.0001:
        x_new = loop_newton(x_new)
    return x_new

x_init = np.array([1, 2])
print(loop_newton(x_init))

